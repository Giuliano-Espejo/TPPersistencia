package com.giulianoespejo.Practico.Persistencia.en.JPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticoPersistenciaEnJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
